This directory contains the Magick++ documentation.

The file NEWS.html is generated from Magick++ source directory via
 txt2html -t 'Magick++ News' < NEWS  > ../www/Magick++/NEWS.html
using Seth Golub's fantastic txt2html translator.
